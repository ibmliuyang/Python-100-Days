curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPOWcnI3/HMzIbkWMEEiBp6YQOK57gddCZwfXThFr1A3+' > 1.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFKEv0q+0flI5xyS4OrAvlQ=' > 2.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPHN3tnwDJ3v9d32mPsoggUw=' > 3.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMfSgSNfHlO/Sqc3x5R2aF8=' > 4.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKxFh8hgv71xW4I89dKc8+I=' > 5.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFqmDGYVpHFQJdVUX9C6v88QOK57gddCZwfXThFr1A3+' > 6.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPN7e3MEfANy+ocXCoK4/9T6I88NURFyivZPV0/JYVGB1' > 7.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPSAb9QgTZdH6k7cVpYAaFC3XhMLcptrZ7GF9wGVyLwg' > 8.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPG8LCdqRuFXCpLGVMF2PEBQ=' > 9.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPC/IGYtGVGrN7CLsNjlyD4A=' > 10.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNHxXfXG4OZxNvbQtGEYp3g=' > 11.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPO8Yzs8AnVwv62yMeHOu9x4=' > 12.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMOM0XiXmX5Ykn/cy4DII5g=' > 13.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMslwAgJVnVEMrFDclcxw2IQOK57gddCZwfXThFr1A3+' > 14.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPHD59HAGflkqhpJ+3PG9rIg=' > 15.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKfWo4kWT7PiOh+c9Ve++Aw=' > 16.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPO2vrtA/zGkvNPaRfrZf010=' > 17.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPHxNhyEYuAvvEXaAoNwlsWE=' > 18.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJWPkH2wB8MYKAwMSGRiP3w=' > 19.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPC/sKWVrhrOIkdQ36NsGtlQ=' > 20.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNX1kgh7Ul97YoY+Kni5HVU=' > 21.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPN1BgtSl3q2/LlUeHp0CHSI=' > 22.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLAmBTWGZXWp93w/xHLwFs0=' > 23.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCWaHhEskWfhal8ZCFMjZe4=' > 24.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCBu1T4vVX6/F8L0iUEtVsQ=' > 25.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPK0UgAvZ8ItPAh7kA+VTf1A=' > 26.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJEv2Y+Z6WR53sndcJm3Phc=' > 27.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNaT1SHXPTTlVJiWYy2WaWo=' > 28.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJaCv5u3gutav421zFU+OP0=' > 29.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPS4VSlxnEMRONv6l5ySE9o=' > 30.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMQC4+xtj8KLnM0z04j7UMEQOK57gddCZwfXThFr1A3+' > 31.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPGuYEO8hzgEHPRVgsv8F0Cg=' > 32.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCfvj+tz3m4+j57Cl09I1ea3XhMLcptrZ7GF9wGVyLwg' > 33.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMbF82OhzGQt3FKlpRUhgow=' > 34.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFeatj7j26xnXiPwnZ7GDJ0=' > 35.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPEkXnrhdr/eIX2UAm81MeNs=' > 36.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPAQxxXIk87Oc1Koznu9JJN4=' > 37.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCRBE/VFdLk8x/JBDJfA06cQOK57gddCZwfXThFr1A3+' > 38.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPHvJB3hBQ/jFA/BHzN35cmIQOK57gddCZwfXThFr1A3+' > 39.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMElSTPQaRJ5mD43s20GafkQOK57gddCZwfXThFr1A3+' > 40.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJ0yu1z04JQgYQrkm9GrQ//w8TJtwUUOdhOTT2QJ7sZk' > 41.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPEHnEq3P1vSxoGg+oUjjiDA=' > 42.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFetkmt9rRFIGRmYUpD/YRsNotexDMfQg+nF++KPOdqe' > 43.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPtTj/olm3gcrc0xKOQUdx0=' > 44.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMKYdalqjCXX3QIgV0qMgTI=' > 45.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJZiR3iusap3CV/DPqR/r18=' > 46.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMlKNLJ/EIcHRYfywv2t5Dy3XhMLcptrZ7GF9wGVyLwg' > 47.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPHt/Eesrm4r1yPEjF19gTJU=' > 48.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPO1GwgDyZf6tSA6Wvue35FIQOK57gddCZwfXThFr1A3+' > 49.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLTNN88TdkRVvxLeflJggwk=' > 50.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFATpz1F6gMnI9lZpBTPckQ=' > 51.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFoam7tglQSRszRPLkDwz2g=' > 52.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPYnnxgsHao94k5sYtxHJv8dhoXPWGIJYg3n8rdgFIni' > 53.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPD1dJ+m+/SefF5DeXvj2u68QOK57gddCZwfXThFr1A3+' > 54.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPAvBxdGCPM8svuFICfcPdpc=' > 55.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPDQo1ivoUGnYiWeyCsBsfQ0QOK57gddCZwfXThFr1A3+' > 56.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPM87i20bOux9SjIE8XgGCD0=' > 57.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPcRANnh3SYtaREnaxxR/o4=' > 58.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJ0b36+PxLgq7cQiGcAj8Pc=' > 59.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPBeCUn3uNx/Ln8d1c9AcmXUQOK57gddCZwfXThFr1A3+' > 60.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKybRGBWY41ZANrbFQC84RI=' > 61.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPP2KwenKy688w6dICoruACc=' > 62.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCvJ908Vp7+ONPoKiGqWShw=' > 63.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMrL7AB8/mP+xxdNLSLejJ51sxup5Fyh6r8AovhzpmhN' > 64.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPK0DzHmBqyl74R/7wRYNclU=' > 65.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMoRlOr2m38vWW3aplLZwXg=' > 66.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPBg1QzWY2d6WCc4rVccMm3xqEA/+v4rb9v8qP5cEVFGx' > 67.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPEfo8iYtwJnAqxjn2tCKpbg=' > 68.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPqrFyqVKyUFkmnneCA6kok=' > 69.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMp5uKmfEj08RwMfkJRwFcU=' > 70.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPD2IQc0mIAAW3fz1pHBjKDsyMcIM2TjDw7kjY8MT7dZS' > 71.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNb5IZxgMssHAUpmEUeTY+c=' > 72.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKnKSjkTrLExDUlVsDzZtdfjd9nB0Q45qAVXkrFN9Dw9' > 73.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPEejsIb2d2+LOwww4Od6l1k=' > 74.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPtEckrLHbIkNN/NQK8n9qc=' > 75.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJQamfkZzFfMYoBSjMiuFxC3XhMLcptrZ7GF9wGVyLwg' > 76.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPPUEJWGQMi/X3RQXOHGGxVZwKcoFGD7kVW9u+PIJaoE0' > 77.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKQlaPLOlw5m77n3ygzh+VH4mTtWmSayRhb/1KxjvQks' > 78.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPBx2geg/NgiDRDJPCBKWdH0=' > 79.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJySPJoDF2OzTSXcHp1d5aE=' > 80.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPDWNQ3yqfhcEGujLuvRVPxM=' > 81.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPBG3ydH/cWIhI7GXUjOIDkA=' > 82.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKbx2aQppqcOCuKp+iywHBI=' > 83.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPDGAcDnZZQRuPWi27XZYzoEQOK57gddCZwfXThFr1A3+' > 84.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLBMuFo5YyeV7uMaJAnojtVqEA/+v4rb9v8qP5cEVFGx' > 85.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLvmPMqy8b0Ui6D9LRL59lRqEA/+v4rb9v8qP5cEVFGx' > 86.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNp2DyohAVI+GQiuJ6oVQ/k=' > 87.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLUBYgauVLUENCBo8zIUit0=' > 88.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNX47wkSjLP6SVlnbYUmYQo=' > 89.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFGLZ+djZbjD2UKYMoQMBSw=' > 90.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNHkIWpJCGCsjhhyELE6Ki+3XhMLcptrZ7GF9wGVyLwg' > 91.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPMckdOR4mvKpJaJlNxAQTYCI88NURFyivZPV0/JYVGB1' > 92.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPNrXrTr/2LMN65VkJclEXzQdUVM56i3AgnSQy4s3fQB+' > 93.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPJLwoD8JvwhmwWNuuboLEfW3XhMLcptrZ7GF9wGVyLwg' > 94.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPEUBwQk0sw+/o3ed8IIkjxE=' > 95.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCgm6VuuweFCNW3ayhBx6Co=' > 96.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLRDWm4Ra2I5MtiZs6Xl6SHzB1q4wld/WUVvk2jFsreC' > 97.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPKYGxfmpqoH9OiXW4Fle7io/iWKfJF6g/hXlOdEryk5M' > 98.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPD7H1FXJs61BFNzTOIvuouo=' > 99.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPLa0r7s04b5Q1IGPiIuKgIk=' > 100.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPO8XE2ovcOqzTwuuQMix4Ks=' > 101.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCbxxwGSTiGZgsoqY5kH/6LPjJR3aBucrjH6+ur5Dhvy' > 102.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPCbxxwGSTiGZgsoqY5kH/6LxIdxWmDLg3osImZsnA002' > 103.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d 'UOB3QX1xAJ2K1/75rWPWPFFpa+c192nC63lX1Rs3fA8=' > 104.txt
sleep 8