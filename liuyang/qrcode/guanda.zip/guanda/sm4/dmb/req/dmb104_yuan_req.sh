curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_DZBZDSZL"}' > 1.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_JDXZ"}' > 2.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_XTCS"}' > 3.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_XTCSBM"}' > 4.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_MSDCLX"}' > 5.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SB_XFSSLPZB"}' > 6.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_FP_DKFPJMSLX"}' > 7.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_JDXZSWJGDZB"}' > 8.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_KJZDZZ"}' > 9.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_DWLSGX"}' > 10.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SFZJLX"}' > 11.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_ZSXM"}' > 12.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_ZSPM"}' > 13.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_GLB_ZSPM"}' > 14.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_ZSZM"}' > 15.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_SBSX"}' > 16.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_NSRZT"}' > 17.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SBFS"}' > 18.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_ZSFS"}' > 19.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_ZSDLFS"}' > 20.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_ZS_SKSX"}' > 21.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_ZS_SKZL"}' > 22.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SBQX"}' > 23.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_NSQX"}' > 24.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_JKQX"}' > 25.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_ZS_TTSFLX"}' > 26.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_PZ_PZZL"}' > 27.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_DJ_DJZCLX"}' > 28.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_FP_FPZT"}' > 29.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_GXDKLX"}' > 30.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_DZFP_TDYSLX"}' > 31.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SWSX"}' > 32.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_YH_SWSXJMXZDZB"}' > 33.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_YH_SSYHLX"}' > 34.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_YH_JMLX"}' > 35.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_YH_JMFS"}' > 36.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SSJMXZ"}' > 37.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SSJMXZDL"}' > 38.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_DJ_KZZTDJLX"}' > 39.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SSJMXZXL"}' > 40.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_SSJMXZYJMZLXDZB"}' > 41.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_YH_JMZLX"}' > 42.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_SSJMXZJMFDEDSLGX"}' > 43.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_JMSXM"}' > 44.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_YH_JMXMDL"}' > 45.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_YH_JMXMXL"}' > 46.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_YH_XEJMJMXZPZB"}' > 47.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SB_PHJMPZB"}' > 48.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SB_JZZCSYZT"}' > 49.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_HY"}' > 50.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_MTSZC"}' > 51.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_JSFF"}' > 52.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_AZZSJJDJKMLX"}' > 53.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_JXSEZCLX"}' > 54.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_LDSEZT"}' > 55.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_NSJCTZLX"}' > 56.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSGCWD"}' > 57.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSPZFL"}' > 58.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSSJQD"}' > 59.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSYSPZLX"}' > 60.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_SWJG"}' > 61.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSYWLX"}' > 62.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSYWXW"}' > 63.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SS_SSYWLXYSSYSPZLXDZ"}' > 64.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SSMSBZ"}' > 65.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_ZZSYJLX"}' > 66.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_SDJMYHSXMC"}' > 67.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_YHHB"}' > 68.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_YHYYWD"}' > 69.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_SPBMDL"}' > 70.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SB_XFSSPBMYSMDY"}' > 71.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_GJHDQ"}' > 72.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SS_SPBMYJMXZDZB"}' > 73.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_JLDW"}' > 74.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SS_JLDWHSB"}' > 75.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SS_XFSPMYHYDZB"}' > 76.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SS_XFSPMYJLDWDZB"}' > 77.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SS_SPBMXFSPMHKCFSDZB"}' > 78.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SS_KCFS"}' > 79.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_JYLB"}' > 80.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_JYLX"}' > 81.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_FCYT"}' > 82.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_XZQH"}' > 83.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_FCSNSRLX"}' > 84.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_SB_FTC_MRQXGZ"}' > 85.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_DJ_FCYZKCLSZB"}' > 86.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_TDYT"}' > 87.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_TDQDFS"}' > 88.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_TDXZ"}' > 89.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_DJ_TDDJ"}' > 90.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_DJ_TDDJZSPMDZB"}' > 91.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_DJ_TDDWSESZB"}' > 92.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_DJ_KDQSSZYQYLX"}' > 93.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_DJ_JDXZXZQHDZB"}' > 94.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_TSNSRLX"}' > 95.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_DJ_SWZJZL"}' > 96.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_GJGHBJNZDRJHJCDLSJLY"}' > 97.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_SB_QYSDSMBKSQYLX"}' > 98.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_ZQTZ"}' > 99.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_JJR"}' > 100.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_SBQXWH"}' > 101.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_ZSXMPMQXGZB_QG"}' > 102.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_CS_GY_ZSXMPMQXGZB_ZDY"}' > 103.txt
sleep 8
curl --request POST 'https://lqpt.guangdong.chinatax.gov.cn:8443/access/sandbox/v2/invoke/206001/CXDMBSJ' --header 'ylbm: 206001' --header 'nlbm: 206001' --header 'sydwptbh: 5d2cff003e35abb0603f' --header 'jrdwptbh: 5d2cff003e35abb0603f' --header 'fwbm: CXDMBSJ' --header 'Content-Type: application/json' -d '{"dmbywmc": "LQ_DM_GY_YWLC"}' > 104.txt
sleep 8